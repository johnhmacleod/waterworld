// This application acts as a proxy to Moximo server. It uses express as it's web server
// for more info, see: http://expressjs.com
var express = require('express');
var log4js = require('log4js');
var bodyParser = require('body-parser');
var workOrder = require('./services/workOrder');
var https = require('https');
var fs = require('fs');
var request = require('request');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// create a new express server
var app = express();

app.use(bodyParser.urlencoded({
  extended: true
}));
// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

//Configure file appender (console is loaded by default)
log4js.loadAppender('file');
//Define the log file name and logger name
log4js.addAppender(log4js.appenders.file('logs/app.log'), 'app');
var logger = log4js.getLogger('app');
//Allow cross domain
var allowCrossDomain = function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // intercept OPTIONS method
  if ('OPTIONS' == req.method) {
    res.send(200);
  } else {
    next();
  }
};
app.use(allowCrossDomain);

//Define createOrder service
app.post('/createWorkOrder', workOrder.createWorkOrder);

app.listen(appEnv.port, appEnv.bind, function() {

  logger.info("Server starting on " + appEnv.url);
});
