//Declare work order service logger
var log4js = require('log4js');
log4js.loadAppender('file');
log4js.addAppender(log4js.appenders.file('logs/service.log'), 'createWO');
var logger = log4js.getLogger('createWO');
var Promise = require('bluebird');
var request = Promise.promisify(require("request"));
var url = require('url');
var cfenv = require('cfenv');
var appEnv = cfenv.getAppEnv();
var secureGatewayURL = 'http://cap-sg-prd-3.integration.ibmcloud.com:15721';
var maximoUser = 'wilson';
var maximoPassword = 'wilson';
var xmlParser = require('xml2json');

function ClientError(e) {
  return e.code >= 400 && e.code < 500;
};

exports.createWorkOrder = function(req, res, callback) {
  console.log(JSON.stringify(req.query));
  logger.info('createWorkOrder is invoked');
  //Construct Maximo create work order service URL
  var maximoServiceURL =
    secureGatewayURL + '/maxrest/rest/os/mxwo?_lid=' + maximoUser + '&_lpwd=' +
    maximoPassword;
  maximoServiceURL = maximoServiceURL + '&siteid=' + req.query.site +
    '&description=' + req.query.description + '&location=' + req.query.location +
    '&assetnum=' + req.query.assetnum;
  console.log('URL:' + maximoServiceURL);
  //Construct request object
  var requestObject = {
    url: maximoServiceURL,
    method: 'POST',
    form: req.body
  };
  //Invoke Create Work Order
  request(requestObject).then(function(contents) {

    var jsonString = xmlParser.toJson(contents.body);
    var maximoResponse = JSON.parse(jsonString);
    //Extract work order number from Maximo response and return the WorkOrderNumber to service consumer
    return res.json({
      'WorkOrderNumber': maximoResponse.CreateMXWOResponse.MXWOSet.WORKORDER
        .WONUM,
      'Test': "Is successful"  
    });
  }).catch(ClientError, function(e) {
    //A client error like 400 Bad Request happened
  });
};
