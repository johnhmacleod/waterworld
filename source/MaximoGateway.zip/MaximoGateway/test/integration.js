var assert = require('assert');
var server = require('../app');
var cfenv = require('cfenv');
var appEnv = cfenv.getAppEnv();
var Promise = require('bluebird');
var request = Promise.promisify(require("request"));
describe('Integration', function() {
  describe('Create Work Order', function() {
    var app;

    it('Return WorkOrder Details', function(done) {
      var url = 'http://' + appEnv.bind + ':' + appEnv.port +
        '/createWorkOrder?description=Device number 7 is fail&location=OFF301&site=BEDFORD';
      this.timeout(30000);
      var requestObject = {
        url: url,
        method: 'POST'

      };
      request(requestObject).then(function(contents) {
        var workOrderNumber = JSON.parse(contents.body).WorkOrderNumber;
        console.log('WorkOrderNumber is ' + workOrderNumber);
        assert
          .equal(workOrderNumber !=
            'undefined', true);
        done();
      });

    });
  });
});
